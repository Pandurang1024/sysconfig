name 'jenkins_plugin'
depends 'jenkins'
